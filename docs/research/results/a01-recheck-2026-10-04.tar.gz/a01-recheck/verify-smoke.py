"""Offline A01 smoke assertions: python verify-smoke.py PATH_TO_CAMPAIGN."""
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
summary = json.loads((root / 'summary.json').read_text())
groups = summary['groups']
assert len(summary['campaign']['runs']) == 26
assert summary['campaign']['jobs'] == 1
assert sum(g['complete_trials'] for g in groups.values()) == 26
assert sum(g['failed_or_missing_trials'] for g in groups.values()) == 0
assert all(g['latency'] == {'n': 0} for g in groups.values())
assert groups['stable/35/events']['delivered_events'] == 30
assert groups['outage/12/events']['delivered_events'] == 1
assert groups['outage/12/events']['withheld_expired_events'] == 1
assert groups['outage/12/events']['eligible_delivery_fraction'] == 1
assert groups['absent/2/events']['discovery_timeouts'] == 1
assert groups['absent/2/events']['delivered_events'] == 0
assert groups['adversarial/3/events']['rejections'] == {
    'signature': 2, 'malformed': 1, 'expired': 1, 'capacity': 0}
assert groups['adversarial/3/events']['delivered_events'] == 1
assert groups['overload/3/events']['rejections']['capacity'] == 24
assert groups['overload/3/events']['delivered_events'] == 9
for mode in ('cold', 'warm'):
    for window in (1, 2, 5, 10):
        assert groups[f'{mode}/{window}/events']['delivered_events'] == 1
for item in summary['campaign']['runs']:
    run = item['run_id']
    assert json.loads((root / f'{run}-exit.json').read_text()) == {'send': 0, 'receive': 0}
    records = {role: [json.loads(line) for line in (root / f'{run}-{role}.jsonl').read_text().splitlines()]
               for role in ('send', 'receive')}
    sent = {(r['event_id'], r['frame_sha256']) for r in records['send']
            if r['kind'] == 'event' and r['outcome'] == 'sent'}
    received = {(r['event_id'], r['frame_sha256']) for r in records['receive'] if r['kind'] == 'received'}
    assert received <= sent
    if item['scenario'] == 'outage' and not item['control_only']:
        events = [r for r in records['send'] if r['kind'] == 'event']
        original = {r['event_id']: r['frame_sha256'] for r in events if r['attempt'] == 'initial'}
        assert all(original[r['event_id']] == r['frame_sha256'] for r in events)
    if item['scenario'] == 'overload' and not item['control_only']:
        recovery = {(r['event_id'], r['frame_sha256']) for r in records['send']
                    if r['kind'] == 'event' and r['attempt'] == 'recovery'}
        assert recovery <= received
print('PASS: 26 sequential trials; delivery, timeout, stale withholding, original resend bytes, signatures, bounded overflow and recovery')
